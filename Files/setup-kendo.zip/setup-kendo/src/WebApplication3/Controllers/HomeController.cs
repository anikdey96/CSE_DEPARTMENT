﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using WebApplication3.Data;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {

        private readonly SchoolContext _context;

        public HomeController(SchoolContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        public ActionResult EditingInline_Read([DataSourceRequest] DataSourceRequest request)
        {
            return Json(_context.Students.ToDataSourceResult(request));
            //return Json(new List<Student>() { new Student() { ID = 1, FirstMidName = "test", LastName="lastName" } }.ToDataSourceResult(request));
        }

        public ActionResult GetNames([DataSourceRequest] DataSourceRequest request)
        {
            var result = new HashSet<string>();

             _context.Students.Each(x => {

                if (x.FirstMidName!= null)
                {
                    result.Add(x.FirstMidName);
                }
                });
           
            return Json(result);

        }



        [AcceptVerbs("Post")]
        public ActionResult EditingInline_Create([DataSourceRequest] DataSourceRequest request, Student student)
        {
            if (student != null && ModelState.IsValid)
            {
                _context.Add(student);
                _context.SaveChanges();
            }

            return Json(new[] { student }.ToDataSourceResult(request, ModelState));
        }

        [AcceptVerbs("Post")]
        public ActionResult EditingInline_Update([DataSourceRequest] DataSourceRequest request, Student student)
        {
            if (student != null && ModelState.IsValid)
            {
                _context.Update(student);
            }

            return Json(new[] { student }.ToDataSourceResult(request, ModelState));
        }

        [AcceptVerbs("Post")]
        public ActionResult EditingInline_Destroy([DataSourceRequest] DataSourceRequest request, Student student)
        {
            if (student != null)
            {
                _context.Students.Remove(student);
            }

            return Json(new[] { student }.ToDataSourceResult(request, ModelState));
        }

       



    }
}
